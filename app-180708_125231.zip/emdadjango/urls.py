from django.conf.urls import include, url
from django.contrib import admin
from dispatcher import views as dviews

urlpatterns = [
    # Examples:
    # url(r'^$', 'emdadjango.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    url(r'^$', dviews.home, name='home'),
    url(r'^maps/$', dviews.index, name='maps'),
    url(r'^ops$', dviews.ops, name='ops'),
    url(r'^reports$', dviews.reports, name='reports'),
]
